const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const Holidays = require('date-holidays');
const version = require('date-holidays/package.json').version;
const destination = path.resolve(__dirname, process.argv[2] || '../admob-integration-20261104/assets/holidays');
fs.mkdirSync(destination, { recursive: true });
const years = [2026, 2027, 2028, 2029, 2030];
const countries = new Holidays().getCountries('en');
// Date facts cross-checked against Diyanet annual lists; no page text copied.
const trEids = {
  2026: ['03-20', '05-27'], 2027: ['03-09', '05-16'],
  2028: ['02-26', '05-05'], 2029: ['02-14', '04-24'], 2030: ['02-04', '04-13'],
};
function day(value, offset) {
  const d = new Date(value + 'T12:00:00Z');
  d.setUTCDate(d.getUTCDate() + offset);
  return d.toISOString().slice(0, 10);
}
function entries(country, state, year) {
  const options = { languages: ['en'], types: ['public'] };
  const hd = state ? new Holidays(country, state, options) : new Holidays(country, options);
  const english = hd.getHolidays(year).filter(h => h.type === 'public');
  hd.setLanguages(['tr', 'en']);
  const turkish = hd.getHolidays(year);
  const rows = [];
  for (const h of english) {
    if (country === 'TR' && /Shawwal|Dhu al-Hijjah/.test(h.rule)) continue;
    const tr = turkish.find(t => t.date === h.date && t.rule === h.rule)?.name || h.name;
    // Civil date from the rule, never the host timezone's Date conversion.
    const date = h.date.slice(0, 10);
    // Expand durations into civil days. Partial-day start/end do not invent a
    // preceding day; Turkey's legal eves are explicitly supplied below.
    const duration = (new Date(h.end) - new Date(h.start)) / 86400000;
    const count = Math.max(1, Math.ceil(duration - 1e-8));
    for (let i = 0; i < count; i++) {
      const d = day(date, i);
      if (!d.startsWith(String(year))) continue;
      rows.push([d, count > 1 ? `${tr} · ${i + 1}. gün` : tr,
        count > 1 ? `${h.name} · Day ${i + 1}` : h.name]);
    }
  }
  if (country === 'TR') {
    rows.push([`${year}-10-28`, 'Cumhuriyet Bayramı arifesi · öğleden sonra', 'Republic Day Eve · afternoon']);
    for (let eid = 0; eid < 2; eid++) {
      const date = `${year}-${trEids[year][eid]}`;
      const tr = eid ? 'Kurban Bayramı' : 'Ramazan Bayramı';
      const en = eid ? 'Eid al-Adha' : 'Eid al-Fitr';
      rows.push([day(date, -1), `${tr} arifesi · öğleden sonra`, `${en} Eve · afternoon`]);
      for (let i = 0; i < (eid ? 4 : 3); i++) rows.push([day(date, i), `${tr} · ${i + 1}. gün`, `${en} · Day ${i + 1}`]);
    }
  }
  return [...new Map(rows.map(row => [row[0] + ':' + row[2], row])).values()]
    .sort((a, b) => a[0].localeCompare(b[0]) || a[2].localeCompare(b[2]));
}
const manifest = { schema: 1, source: `date-holidays ${version}`, firstYear: years[0], lastYear: years.at(-1),
  dataLicense: 'CC BY-SA 3.0', countries: {}, sha256: {}, modifications: [
    'Public holidays only; TR/EN names; durations expanded into civil-day cards.',
    'Turkey Eid dates checked against Diyanet 2026–2030; legal eves added.',
    'Full national and first-level subdivision schedules retained separately.',
  ], verifiedTurkeySources: [
    'https://vakithesaplama.diyanet.gov.tr/dinigunler.php?yil=2026',
    ...[154,185,186,187].map(id => `https://vakithesaplama.diyanet.gov.tr/icerik.php?icerik=${id}`),
  ] };
let regionCount = 0, rowCount = 0;
for (const [country, name] of Object.entries(countries)) {
  const states = new Holidays().getStates(country, 'en') || {};
  const bundle = { schema: 1, country, sourceVersion: version, regions: states, years: {} };
  for (const year of years) {
    const schedules = { '': entries(country, null, year) };
    for (const state of Object.keys(states)) schedules[state] = entries(country, state, year);
    bundle.years[year] = schedules;
    for (const rows of Object.values(schedules)) rowCount += rows.length;
  }
  const bytes = JSON.stringify(bundle);
  fs.writeFileSync(path.join(destination, country + '.json'), bytes);
  manifest.countries[country] = name;
  manifest.sha256[country] = crypto.createHash('sha256').update(bytes).digest('hex');
  regionCount += Object.keys(states).length;
  process.stdout.write(country + ' ');
}
fs.copyFileSync(path.join(__dirname, 'node_modules/date-holidays/LICENSE'), path.join(destination, 'LICENSE.txt'));
fs.writeFileSync(path.join(destination, 'manifest.json'), JSON.stringify(manifest, null, 2));
fs.writeFileSync(path.join(destination, 'ATTRIBUTION.txt'),
  `Holiday data derived from date-holidays ${version}, commenthol and its contributors.\n` +
  'Source: https://github.com/commenthol/date-holidays\nData: CC BY-SA 3.0; code: ISC.\n' +
  'https://creativecommons.org/licenses/by-sa/3.0/\nFull upstream attribution list: LICENSE.txt.\n' +
  'Adaptations by Seni Dinliyorum (2026): public-only JSON, civil-day expansion, TR/EN labels, Turkey date verification and eves.\n' +
  'These adapted data files are distributed under CC BY-SA 3.0. No warranty of date accuracy or completeness.\n' +
  'See manifest.json for version, date-verification sources and coverage.\n');
console.log(JSON.stringify({ countries: Object.keys(countries).length, subdivisions: regionCount, years, rows: rowCount }));
