# Çevrim dışı bayram paketi

Kaynak: date-holidays 3.38.0, 2026–2030; 207 ülke ve 366 birinci düzey kaynak bölgesi. Veri boyutu yaklaşık 2,1 MB. Kapsam kaynağın tanımladığı resmî tatillerdir; tüm yerel anma günleri, okul tatilleri ve sonradan ilan edilen özel günleri kapsadığı iddia edilmez. Daha alt düzey bölgeler bu pakete dahil değildir.

## Davranış
- Dart yalnız paketlenmiş varlıkları okur. Android HTTP tatil istemcisi kaldırıldı; iOS eski tatiller kanal metodu ağ bağlantısı açmadan boş yanıt verir.
- Kullanıcının ülke/bölge tercih anahtarları ve kişisel kayıtları korunur. Eski Nager.Date veri önbelleği okunmaz veya yeni kaynaktanmış gibi yeniden yayımlanmaz; kullanıcı verisi silinmez.
- Yeni yüklemede de internet olmadan çalışır. Ülke/yıl sunucuya gönderilmez.
- Desteklenmeyen yıl/ülke veya bölge için Bugün ve ülke ayarlarında açıklama gösterilir. Eksik bölge ulusal takvime döner; başka bölge verileri kullanılmaz.
- TR/EN metinler kaynak dil verisini ve mevcut çevirileri kullanır; kaynakta çevirisi bulunmayan özel gün adları İngilizce kalabilir.
- Aynı güne denk gelen farklı bayramlar korunur, aynı tarih/başlık iki kere gösterilmez.
- Türkiye Ramazan/Kurban Bayramı 2026–2030 günleri Diyanet'in yıllık listeleriyle kontrol edildi; arife öğleden sonraları ve çok günlük bayram numaraları eklendi.
- Dinî tarihler ülkeye göre gözlem ve resmî ilanlarla değişebilir. Yıllık bakım/güncelleme gerekir. 2030 sonrasında veri paketi yenilenmelidir.

## Kaynak ve lisans
Varlık klasöründeki ATTRIBUTION.txt, LICENSE.txt ve manifest.json dağıtımın parçasıdır. Uygulamanın Bayramların ülkesi/bölgesi ayarında lisanslar ekranına erişim var. Kaynak kodu ISC; kullanılan veri lisansı, paketteki tam LICENSE uyarınca CC BY-SA 3.0 olarak korunmuştur. package.json kısa lisans etiketi yerine tam lisans dosyası esas alınmıştır.

Uyarlanan veri bağımsız `output/holiday-data-2026-2030-3.38.0.zip` paketinde de bulunur. Yeni mağaza dağıtımından önce bu paketi ve lisansını geliştirici sitesinde bağımsız indirilebilir hale getir; politika/lisans sayfasına bağlantı ekle. Uygulama mağazasının lisans/DRM kısıtlarını veri paketine uygulama. Kamuya açık veri yayını bu yerel kod değişikliği sırasında yapılmadı.

## Yeniden üretme
Çalışma alanındaki work/holiday-data-generator/package-lock.json bağımlılıkları sabitler. `npm ci --ignore-scripts` ardından `node generate.cjs <çıktı-klasörü>` kullanılır. Node ve üretici yalnız derleme/bakım aracıdır; telefonda çalıştırılmaz. Yeni tarihler için üretici içindeki Türkiye doğrulama tablosu ve manifestteki kaynaklar da güncellenmelidir.

## Yayın ve geri dönüş
Önceki kaynak yedeği: backups/admob-integration-20261104/source-before-offline-holidays-20261105.zip. Değişiklikler yalnız work/admob-integration-20261104 kopyasında; eski mağaza sürümleri korunur. Güncel gizlilik politikalarında Nager.Date sunucu sorgusu açıklaması yerine paketlenmiş veri, kaynak ve güncelleme kapsamı yazılmalı. Yayımlanmış eski sürümlerin politikasını, bu değişiklik dağıtılmadan yanlış biçimde yeni davranışı anlatacak şekilde değiştirme.
